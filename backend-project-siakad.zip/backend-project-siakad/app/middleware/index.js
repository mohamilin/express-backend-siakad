const verifyRegister = require("./verifyRegister");
const authJwt = require("./authJWT");

module.exports = {
    verifyRegister,
    authJwt
}