require("dotenv").config();

module.exports = {
    uri : process.env.DB_PROJECT
}